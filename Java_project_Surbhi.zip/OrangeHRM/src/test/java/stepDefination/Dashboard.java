package stepDefination;

import PageObject.DashboardPageObject;
import PageObject.LoginPageObject;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class Dashboard {
    DashboardPageObject dashoard;
    WebDriver driver;
    @Given("^Dashboard is visible$")
    public void dashboard_is_visible() {
        dashoard=new DashboardPageObject(driver);
        dashoard.clickadmin().isDisplayed();
    }

    @When("^User click on Admin$")
    public void user_click_on_admin() {
        dashoard.clickadmin().click();
    }

    @When("^User click on User Management$")
    public void user_click_on_user_management() {
        dashoard.clickusermanagement().isDisplayed();
     dashoard.clickusermanagement().click();
    }

    @When("^User click on User$")
    public void user_click_on_user() {
        dashoard.clickuser().isDisplayed();
        dashoard.clickuser().click();
    }

    @Then("^User should redirect to the System User$")
    public void user_should_redirect_to_the_system_user() {
        dashoard.clickadd().isDisplayed();
    }



    @Given("^System user Screen$")
    public void systemscreen(){
    }

}
