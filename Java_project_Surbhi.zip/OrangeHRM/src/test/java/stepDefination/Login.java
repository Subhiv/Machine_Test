package stepDefination;
import Common.CommonMethods;
import PageObject.LoginPageObject;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Login extends CommonMethods {

    LoginPageObject l;
    WebDriver driver;
    @Given("^OrangeHRM Login panel$")
    public void loginPanl() throws IOException {
        driver =BrowserInitiaize();
        l=new LoginPageObject(driver);
        driver.get("https://opensource-demo.orangehrmlive.com");
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

    }

    @When("^User going to enter username and password$")
    public void enterCred() {
        l.inputuser().sendKeys("Admin");
        l.inputpswd().sendKeys("admin123");
    }

    @Then("Click on Login")
    public void Clicklogin() {
        l.login().click();
    }
    @Then("Verify user reach to the dashboard")
    public void verifydashboard() {
        l.verify().isDisplayed();
            }


}
