package Common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

public class CommonMethods {



    public WebDriver BrowserInitiaize() throws IOException {
        WebDriver driver = null;
        Properties pro = new Properties();
        FileInputStream fs = new FileInputStream("src/main/resources/data.properties");
        pro.load(fs);
        String browserName = pro.getProperty("browser");
        System.out.println(browserName);

        if (browserName.contains("Chrome")) {
            System.setProperty("webdriver.chrome.driver", "src/main/java/BrowserDrivers/chromedriver.exe");
            driver =new ChromeDriver();

        }
        if (browserName.contains("Firefox")) {
            System.setProperty("webdriver.gecko.driver", "src/main/java/BrowserDrivers/geckodriver.exe");
             driver = new FirefoxDriver();
            //if(browser)
        }

        return driver;
    }
}
