package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageObject {




    public WebDriver driver;
    By Inputuser = By.xpath("//input[@name='txtUsername']");
    By Inputpasswd = By.xpath("//input[@id='txtPassword']");
    By LoginBtn = By.xpath("//input[@id='btnLogin']");
    By verfy = By.id("menu_admin_viewAdminModule123");

    public LoginPageObject(WebDriver driver) {
       this.driver=driver;
    }

    public WebElement inputuser(){
        return driver.findElement(Inputuser);
    }
    public WebElement inputpswd(){
        return driver.findElement(Inputpasswd);
    }
    public WebElement login(){
        return driver.findElement(LoginBtn);
    }
    public WebElement verify(){
        return driver.findElement(verfy);
    }
}
