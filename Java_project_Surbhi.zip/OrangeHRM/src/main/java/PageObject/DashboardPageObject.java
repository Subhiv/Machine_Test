package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DashboardPageObject {
//input[@id='btnAdd']


    public WebDriver driver;
    By AdminBtn = By.id("menu_admin_viewAdminModule");
    By UsermanagementBtn = By.cssSelector("a#menu_admin_UserManagement");
    By usersBtn = By.xpath("//a[text()=\"Users\"]");
    By AddBtn = By.xpath("input#btnAdd");

    //form
    By InputEmployeeName = By.cssSelector("input.formInputText.inputFormatHint.ac_input");
    By InputUsername = By.cssSelector("input#systemUser_employeeName_empName");
    By Inputpassword = By.cssSelector("input#systemUser_password.formInputText.password");
    By InputConfirmpswd = By.cssSelector("input#systemUser_confirmPassword.formInputText.password");
    By ClickSaveform = By.cssSelector("input#btnSave.addbutton");
    By welcomeUser = By.cssSelector("a#welcome.panelTrigger");
    By logout = By.cssSelector("//a[contains(@href,'logout']");

    //Constructor
    public DashboardPageObject(WebDriver driver) {
        this.driver=driver;
    }

    //Dashboard
    public WebElement clickadmin(){
        return driver.findElement(AdminBtn);
    }
    public WebElement clickusermanagement(){
        return driver.findElement(UsermanagementBtn);
    }
    public WebElement clickuser(){
        return driver.findElement(usersBtn);
    }
    public WebElement clickadd(){
        return driver.findElement(AddBtn);
    }

    //Add details employee
    public WebElement employename(){
        return driver.findElement(InputEmployeeName);
    }
    public WebElement username(){
        return driver.findElement(InputUsername);
    }
    public WebElement password(){
        return driver.findElement(Inputpassword);
    }
    public WebElement confirmPassword(){
        return driver.findElement(InputConfirmpswd);
    }
    public WebElement Welcome(){
        return driver.findElement(welcomeUser);
    }
    public WebElement Logout(){
        return driver.findElement(logout);
    }

}
